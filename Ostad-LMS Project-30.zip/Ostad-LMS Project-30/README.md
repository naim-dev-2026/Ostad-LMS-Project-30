# Full-Stack Role-Based Learning Management System (LMS)

A robust, enterprise-grade, role-based Learning Management System built using a decoupled architecture layout. The application utilizes a React frontend container and a secure Django REST Framework (DRF) backend layer wired directly to a relational PostgreSQL database engine.

## 🚀 Key Features Built
- **JWT Authentication Engine:** Secure user registration, multi-tier login tokens, signature extraction decoding, and instant cache token logouts.
- **Password Management Utilities:** Custom backend token-driven Account Recovery workflow printing verification endpoints dynamically to the server console log outputs.
- **Relational Data Mapping Models:** Comprehensive database schemas structuring complete Admin, Instructor, and Student profiles alongside live Category metrics and dynamic Student Course Enrollment maps.
- **Role-Wise Metrics Dashboard Panel:** Interactive analytical dashboard calculation tables rendering cross-platform summaries, platform enrollment counts, and user registration bar charts dynamically from live database rows.

## 💻 Technolgies Stack Overview
- **Frontend Core Framework:** React (Vite compilation engine), Axios networking wrappers, React Router DOM management routers.
- **Backend Core Framework:** Django, Django REST Framework (DRF), SimpleJWT encryption modules, Django-CORS-Headers filters.
- **Relational Database Layer Engine:** PostgreSQL, managed visually inside pgAdmin 4 connection consoles.

## 🛠️ Local Environment Workspace Setup Guide

### 1. Database Connection Initialization
- Open pgAdmin 4 and run a query block to initialize a clean container: `CREATE DATABASE lms_db;`
- Update the parameters tracking dictionary rows sitting within `Backend/lms_backend/settings.py` to target your local server connection profile credentials.

### 2. Backend Environment Configurations Setup
Open a terminal shell pane navigated directly within your `Backend/` tracking folder path, run the system migration pushes, and boot up your local execution server:
```bash
# Apply standard database table structures to PostgreSQL
python manage.py makemigrations authentication
python manage.py makemigrations courses
python manage.py migrate

# Boot up the backend development server runtime engine
python manage.py runserver
```

### 3. Frontend App Dependencies Restorations Setup
Open a separate, concurrent terminal workspace pane navigated inside your `Frontend/` folder path, restore the package modules, and spin the client compiler up:
```bash
# Restore project code dependencies packages matching application specifications
npm install

# Start the application client development server wrapper
npm run dev
```

