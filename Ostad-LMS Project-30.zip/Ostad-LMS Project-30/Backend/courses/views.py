# courses/views.py
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db.models import Count
from django.utils import timezone
from rest_framework import generics, status
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import BasePermission, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Category, Course, Enrollment
from .serializers import CourseSerializer, EnrollmentSerializer

VALID_ROLES = ['student', 'instructor', 'admin']


def get_role(user):
    return str(getattr(user, 'role', 'student') or 'student').lower()


def is_instructor(user):
    role = getattr(user, 'role', None)
    # If the user model has no role field, don't block anyone
    return role is None or str(role).lower() == 'instructor'


class IsPlatformAdmin(BasePermission):
    """Only users whose role is 'admin' (or Django superusers)."""

    def has_permission(self, request, view):
        user = request.user
        return bool(user and user.is_authenticated and (user.is_superuser or get_role(user) == 'admin'))


class CourseListCreateView(generics.ListCreateAPIView):
    queryset = Course.objects.all().order_by('-created_at')
    serializer_class = CourseSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        if not is_instructor(self.request.user):
            raise PermissionDenied('Only instructors can create courses.')
        serializer.save(instructor=self.request.user)


class EnrollView(generics.CreateAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        course = serializer.validated_data['course']
        if Enrollment.objects.filter(student=request.user, course=course).exists():
            return Response({'error': 'You are already enrolled in this course.'},
                            status=status.HTTP_400_BAD_REQUEST)
        serializer.save(student=request.user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class MyEnrollmentsView(generics.ListAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Enrollment.objects.filter(student=self.request.user)


class InstructorStatsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        total = (Enrollment.objects
                 .filter(course__instructor=request.user)
                 .values('student').distinct().count())
        return Response({'total_learners': total})


class DashboardSummaryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        User = get_user_model()
        has_role = any(f.name == 'role' for f in User._meta.get_fields())
        students = User.objects.filter(role__iexact='student').count() if has_role else 0
        instructors = User.objects.filter(role__iexact='instructor').count() if has_role else 0

        taught = Course.objects.filter(instructor=request.user).count()
        learners = (Enrollment.objects
                    .filter(course__instructor=request.user)
                    .values('student').distinct().count())

        return Response({
            'global': {
                'total_users': User.objects.count(),
                'total_courses': Course.objects.count(),
                'total_enrollments': Enrollment.objects.count(),
                'role_counts': {'students': students, 'instructors': instructors},
            },
            'instructor_specific': {'courses_taught': taught, 'total_learners': learners},
        })


class ProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({
            'username': user.username,
            'email': user.email,
            'role': get_role(user),
        })

    def put(self, request):
        User = get_user_model()
        user = request.user
        username = str(request.data.get('username', '')).strip()
        email = str(request.data.get('email', '')).strip()

        if not username:
            return Response({'error': 'Username cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)
        if User.objects.exclude(pk=user.pk).filter(username=username).exists():
            return Response({'error': 'That username is already taken.'}, status=status.HTTP_400_BAD_REQUEST)

        user.username = username
        user.email = email
        user.save()
        return Response({'message': 'Profile updated successfully!'})


# ---------------- Admin-only endpoints ----------------

class AdminUserListView(APIView):
    permission_classes = [IsPlatformAdmin]

    def get(self, request):
        User = get_user_model()
        users = User.objects.all().order_by('id')
        data = [{
            'id': u.id,
            'username': u.username,
            'email': u.email,
            'role': get_role(u),
            'is_active': u.is_active,
            'date_joined': u.date_joined,
        } for u in users]
        return Response(data)


class AdminUserDetailView(APIView):
    permission_classes = [IsPlatformAdmin]

    def patch(self, request, pk):
        User = get_user_model()
        try:
            target = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'error': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)

        if target.pk == request.user.pk:
            return Response({'error': 'You cannot change your own role.'}, status=status.HTTP_400_BAD_REQUEST)
        if not any(f.name == 'role' for f in User._meta.get_fields()):
            return Response({'error': 'The user model has no role field.'}, status=status.HTTP_400_BAD_REQUEST)

        new_role = str(request.data.get('role', '')).lower()
        if new_role not in VALID_ROLES:
            return Response({'error': 'Role must be one of: ' + ', '.join(VALID_ROLES) + '.'},
                            status=status.HTTP_400_BAD_REQUEST)

        target.role = new_role
        target.save()
        return Response({'message': f'{target.username} is now {new_role}.'})

    def delete(self, request, pk):
        User = get_user_model()
        try:
            target = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'error': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)

        if target.pk == request.user.pk:
            return Response({'error': 'You cannot delete your own account.'}, status=status.HTTP_400_BAD_REQUEST)

        name = target.username
        target.delete()
        return Response({'message': f'User {name} was deleted.'})


class AdminCourseDeleteView(APIView):
    permission_classes = [IsPlatformAdmin]

    def delete(self, request, pk):
        try:
            course = Course.objects.get(pk=pk)
        except Course.DoesNotExist:
            return Response({'error': 'Course not found.'}, status=status.HTTP_404_NOT_FOUND)
        title = course.title
        course.delete()
        return Response({'message': f'Course "{title}" was deleted.'})


class AdminEnrollmentListView(APIView):
    permission_classes = [IsPlatformAdmin]

    def get(self, request):
        rows = Enrollment.objects.select_related('student', 'course').order_by('-id')
        data = [{
            'id': e.id,
            'student_name': e.student.username,
            'course_id': e.course.id,
            'course_title': e.course.title,
            'enrolled_at': e.enrolled_at,
        } for e in rows]
        return Response(data)


class AdminEnrollmentDeleteView(APIView):
    permission_classes = [IsPlatformAdmin]

    def delete(self, request, pk):
        try:
            enrollment = Enrollment.objects.select_related('student', 'course').get(pk=pk)
        except Enrollment.DoesNotExist:
            return Response({'error': 'Enrollment not found.'}, status=status.HTTP_404_NOT_FOUND)
        label = f'{enrollment.student.username} from "{enrollment.course.title}"'
        enrollment.delete()
        return Response({'message': f'Removed {label}.'})


# ---------------- Step 2: Categories ----------------

class AdminCategoryListView(APIView):
    permission_classes = [IsPlatformAdmin]

    def get(self, request):
        counts = {row['category']: row['n']
                  for row in Course.objects.values('category').annotate(n=Count('id'))}
        data = [{
            'id': c.id,
            'name': c.name,
            'course_count': counts.get(c.id, 0),
        } for c in Category.objects.all().order_by('name')]
        return Response(data)

    def post(self, request):
        name = str(request.data.get('name', '')).strip()
        if not name:
            return Response({'error': 'Category name cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)
        if Category.objects.filter(name__iexact=name).exists():
            return Response({'error': 'That category already exists.'}, status=status.HTTP_400_BAD_REQUEST)
        category = Category.objects.create(name=name)
        return Response({'message': f'Category "{category.name}" was added.', 'id': category.id},
                        status=status.HTTP_201_CREATED)


class AdminCategoryDetailView(APIView):
    permission_classes = [IsPlatformAdmin]

    def patch(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found.'}, status=status.HTTP_404_NOT_FOUND)

        name = str(request.data.get('name', '')).strip()
        if not name:
            return Response({'error': 'Category name cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)
        if Category.objects.exclude(pk=pk).filter(name__iexact=name).exists():
            return Response({'error': 'Another category already has that name.'}, status=status.HTTP_400_BAD_REQUEST)

        category.name = name
        category.save()
        return Response({'message': f'Category renamed to "{name}".'})

    def delete(self, request, pk):
        try:
            category = Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found.'}, status=status.HTTP_404_NOT_FOUND)

        in_use = Course.objects.filter(category=category).count()
        if in_use:
            return Response(
                {'error': f'Cannot delete "{category.name}": {in_use} course(s) still use it. '
                          'Delete or move those courses first.'},
                status=status.HTTP_400_BAD_REQUEST)

        name = category.name
        category.delete()
        return Response({'message': f'Category "{name}" was deleted.'})


# ---------------- Step 3: Reports ----------------

class AdminReportsView(APIView):
    permission_classes = [IsPlatformAdmin]

    def get(self, request):
        User = get_user_model()

        # Enrollments per course (including courses with zero)
        enroll_counts = {row['course']: row['n']
                         for row in Enrollment.objects.values('course').annotate(n=Count('id'))}
        per_course = [{'label': c.title, 'value': enroll_counts.get(c.id, 0)}
                      for c in Course.objects.all()]
        per_course.sort(key=lambda r: r['value'], reverse=True)

        # Courses per category
        cat_counts = {row['category']: row['n']
                      for row in Course.objects.values('category').annotate(n=Count('id'))}
        per_category = [{'label': c.name, 'value': cat_counts.get(c.id, 0)}
                        for c in Category.objects.all().order_by('name')]

        # New users per week (last 8 weeks, oldest first)
        now = timezone.now()
        weekly = []
        for i in range(7, -1, -1):
            end = now - timedelta(weeks=i)
            start = end - timedelta(weeks=1)
            count = User.objects.filter(date_joined__gte=start, date_joined__lt=end).count()
            weekly.append({'label': end.strftime('%d %b'), 'value': count})
        # Users who joined in the last moments belong to the final bucket
        weekly[-1]['value'] += User.objects.filter(date_joined__gte=now).count()

        # Users by role
        has_role = any(f.name == 'role' for f in User._meta.get_fields())
        by_role = []
        if has_role:
            for r in VALID_ROLES:
                by_role.append({'label': r.capitalize(), 'value': User.objects.filter(role__iexact=r).count()})

        return Response({
            'enrollments_per_course': per_course,
            'courses_per_category': per_category,
            'new_users_per_week': weekly,
            'users_by_role': by_role,
        })