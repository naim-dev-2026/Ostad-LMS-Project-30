# courses/serializers.py
from rest_framework import serializers
from .models import Category, Course, Enrollment


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']


class CourseSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    instructor_name = serializers.CharField(source='instructor.username', read_only=True)
    # Write-only: the React form sends a category NAME; it is created if missing
    category_input = serializers.CharField(write_only=True, required=False, allow_blank=True)

    class Meta:
        model = Course
        fields = ['id', 'title', 'category', 'category_name', 'category_input',
                  'instructor', 'instructor_name', 'description', 'duration', 'lessons', 'created_at']
        read_only_fields = ['instructor']  # Set in the view from the logged-in user
        extra_kwargs = {'category': {'required': False}}

    def create(self, validated_data):
        name = (validated_data.pop('category_input', '') or '').strip() or 'General'
        if not validated_data.get('category'):
            validated_data['category'], _ = Category.objects.get_or_create(name=name)
        return super().create(validated_data)


class EnrollmentSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.username', read_only=True)
    course_title = serializers.CharField(source='course.title', read_only=True)

    class Meta:
        model = Enrollment
        fields = ['id', 'student', 'student_name', 'course', 'course_title', 'enrolled_at']
        read_only_fields = ['student']  # Set in the view from the logged-in user
