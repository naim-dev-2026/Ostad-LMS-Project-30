# courses/urls.py
from django.urls import path
from .views import (CourseListCreateView, EnrollView, MyEnrollmentsView,
                    InstructorStatsView, DashboardSummaryView, ProfileView,
                    AdminUserListView, AdminUserDetailView, AdminCourseDeleteView,
                    AdminEnrollmentListView, AdminEnrollmentDeleteView,
                    AdminCategoryListView, AdminCategoryDetailView, AdminReportsView)

urlpatterns = [
    path('my-enrollments/', MyEnrollmentsView.as_view(), name='my_enrollments'),
    path('enroll/', EnrollView.as_view(), name='enroll'),
    path('instructor-stats/', InstructorStatsView.as_view(), name='instructor_stats'),
    path('dashboard-summary/', DashboardSummaryView.as_view(), name='dashboard_summary'),
    path('profile/', ProfileView.as_view(), name='profile'),

    # Admin only
    path('admin/users/', AdminUserListView.as_view(), name='admin_users'),
    path('admin/users/<int:pk>/', AdminUserDetailView.as_view(), name='admin_user_detail'),
    path('admin/courses/<int:pk>/', AdminCourseDeleteView.as_view(), name='admin_course_delete'),
    path('admin/enrollments/', AdminEnrollmentListView.as_view(), name='admin_enrollments'),
    path('admin/enrollments/<int:pk>/', AdminEnrollmentDeleteView.as_view(), name='admin_enrollment_delete'),
    path('admin/categories/', AdminCategoryListView.as_view(), name='admin_categories'),
    path('admin/categories/<int:pk>/', AdminCategoryDetailView.as_view(), name='admin_category_detail'),
    path('admin/reports/', AdminReportsView.as_view(), name='admin_reports'),

    path('', CourseListCreateView.as_view(), name='course_list_create'),
]
