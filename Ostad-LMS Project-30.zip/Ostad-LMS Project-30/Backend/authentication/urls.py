# authentication/urls.py
from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    RegisterView, 
    CustomLoginView, 
    ForgotPasswordView, 
    ResetPasswordConfirmView
)

urlpatterns = [
    # 1. Sign-Up Route
    path('register/', RegisterView.as_view(), name='auth_register'),
    
    # 2. Sign-In Route (tokens now include username and role)
    path('login/', CustomLoginView.as_view(), name='token_obtain_pair'),
    
    # 3. Token Refresh Route
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    # FIXED: Added missing password management recovery assignment endpoints routes
    path('forgot-password/', ForgotPasswordView.as_view(), name='auth_forgot_password'),
    path('reset-password-confirm/', ResetPasswordConfirmView.as_view(), name='auth_reset_password_confirm'),
]


