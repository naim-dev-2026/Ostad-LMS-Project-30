# authentication/serializers.py
from rest_framework import serializers
from django.contrib.auth import get_user_model

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)  # Keeps password hidden in API responses

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'role']

    def create(self, validated_data):
        # 1. First, extract the custom role tracking string out of the validation dict
        user_role = validated_data.pop('role', 'student')
        
        # 2. Use create_user with only standard parameters to guarantee flawless password hashing
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
        
        # 3. Explicitly assign the custom choice parameter to your model field layer and save
        user.role = user_role
        user.save()
        
        return user

