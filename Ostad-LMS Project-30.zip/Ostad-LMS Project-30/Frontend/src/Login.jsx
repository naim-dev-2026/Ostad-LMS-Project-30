// src/Login.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import API from './api';

const Login = () => {
    const [formData, setFormData] = useState({ username: '', password: '' });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setMessage('');
        setError('');
        try {
            // No leading slash so it appends cleanly onto the axios baseURL
            const res = await API.post('auth/login/', formData);
            localStorage.setItem('access_token', res.data.access);
            localStorage.setItem('refresh_token', res.data.refresh);
            localStorage.setItem('username', formData.username);

            // Decode the JWT payload (2nd segment, base64url) to read the role claim
            const base64 = res.data.access.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
            const payload = JSON.parse(atob(base64));
            localStorage.setItem('role', payload.role || 'student');

            setMessage('Logged in successfully! Redirecting...');

            setTimeout(() => {
                navigate('/dashboard');
            }, 1500);

        } catch (err) {
            setError('Invalid username or password. Please try again.');
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: '40px', fontFamily: '"Segoe UI", Roboto, sans-serif' }}>
            <div style={{
                width: '100%',
                maxWidth: '450px',
                backgroundColor: '#ffffff',
                padding: '40px',
                borderRadius: '16px',
                boxShadow: '0 10px 25px rgba(0, 0, 0, 0.05)',
                boxSizing: 'border-box'
            }}>
                <h2 style={{ textAlign: 'center', fontSize: '28px', fontWeight: '700', color: '#1a1a1a', marginBottom: '8px' }}>Welcome Back</h2>
                <p style={{ textAlign: 'center', color: '#666', fontSize: '14px', marginBottom: '32px' }}>Sign in to access your dashboard courses</p>

                <form onSubmit={handleLogin}>
                    <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>Username</label>
                        <input type="text" placeholder="Enter your username" value={formData.username} style={inputStyle} onChange={(e) => setFormData({ ...formData, username: e.target.value })} required />
                    </div>

                    <div style={{ marginBottom: '10px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>Password</label>
                        <input type="password" placeholder="••••••••" value={formData.password} style={inputStyle} onChange={(e) => setFormData({ ...formData, password: e.target.value })} required />
                    </div>

                    <div style={{ textAlign: 'right', marginBottom: '25px' }}>
                        <Link to="/forgot-password" style={{ color: '#4f46e5', fontSize: '13px', textDecoration: 'none', fontWeight: '600' }}>
                            Forgot Password?
                        </Link>
                    </div>

                    <button type="submit" style={{
                        width: '100%',
                        padding: '14px',
                        backgroundColor: '#10b981',
                        color: '#ffffff',
                        border: 'none',
                        borderRadius: '8px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer'
                    }}>
                        Sign In
                    </button>
                </form>

                {message && <div style={{ color: '#155724', backgroundColor: '#d4edda', padding: '12px', borderRadius: '6px', marginTop: '20px', textAlign: 'center', fontSize: '14px' }}>{message}</div>}
                {error && <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '12px', borderRadius: '6px', marginTop: '20px', textAlign: 'center', fontSize: '14px' }}>{error}</div>}

                <p style={{ marginTop: '28px', textAlign: 'center', fontSize: '14px', color: '#666' }}>
                    Don't have an account yet? <Link to="/signup" style={{ color: '#10b981', fontWeight: '600', textDecoration: 'none' }}>Sign Up</Link>
                </p>
            </div>
        </div>
    );
};

const inputStyle = {
    width: '100%',
    padding: '12px 16px',
    boxSizing: 'border-box',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    fontSize: '15px',
    backgroundColor: '#f9fafb',
    color: '#333',
    outline: 'none'
};

export default Login;