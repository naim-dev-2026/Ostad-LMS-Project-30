// src/Profile.jsx
import React, { useState } from 'react';

const Profile = ({ userProfile, onFlash, style }) => {
    const [email, setEmail] = useState(userProfile.email || `${userProfile.username}@example.com`);
    const [fullName, setFullName] = useState(userProfile.username);

    const handleSave = (e) => {
        e.preventDefault();
        onFlash('Success! Profile identity updates saved cleanly.');
    };

    return (
        <div style={{ backgroundColor: '#ffffff', padding: '35px', borderRadius: '12px', border: '1px solid #e2e8f0', maxWidth: '600px', margin: '0 auto' }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '22px', color: '#0f172a' }}>Account Profile Management</h3>
            <p style={{ margin: '0 0 25px 0', color: '#64748b', fontSize: '14px' }}>Review or edit your profile parameters below.</p>
            
            <form onSubmit={handleSave}>
                <div style={{ marginBottom: '20px' }}>
                    <label style={style.modalLabelStyle}>Profile Tier Role (Read Only)</label>
                    <input type="text" style={{ ...style.modalInputStyle, backgroundColor: '#f1f5f9', color: '#64748b', cursor: 'not-allowed' }} value={userProfile.role} disabled />
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <label style={style.modalLabelStyle}>Active System Username</label>
                    <input type="text" style={style.modalInputStyle} value={fullName} onChange={e => setFullName(e.target.value)} required />
                </div>
                <div style={{ marginBottom: '25px' }}>
                    <label style={style.modalLabelStyle}>Registered Email Address</label>
                    <input type="email" style={style.modalInputStyle} value={email} onChange={e => setEmail(e.target.value)} required />
                </div>
                <button type="submit" style={{ ...style.enrollButtonStyle, width: 'auto', padding: '12px 24px' }}>Save Changes</button>
            </form>
        </div>
    );
};

export default Profile;
