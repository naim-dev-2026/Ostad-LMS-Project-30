// src/Dashboard.jsx
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import API from './api';

const getProfile = () => {
    const fallback = {
        username: localStorage.getItem('username') || 'User',
        role: (localStorage.getItem('role') || 'student').toLowerCase(),
    };
    const token = localStorage.getItem('access_token');
    if (!token) return fallback;
    try {
        const decoded = jwtDecode(token);
        return {
            username: decoded.username || fallback.username,
            role: String(decoded.role || fallback.role).toLowerCase(),
        };
    } catch {
        return fallback;
    }
};

const emptyCourse = { title: '', categoryName: 'Development', description: '', duration: '8 Weeks', lessons: '24 Lessons' };
const emptyStats = { total_users: 0, total_courses: 0, total_enrollments: 0, role_counts: { students: 0, instructors: 0 } };
const emptyReports = { enrollments_per_course: [], courses_per_category: [], new_users_per_week: [], users_by_role: [] };

const Dashboard = () => {
    const navigate = useNavigate();
    const mainRef = useRef(null);

    const [userProfile, setUserProfile] = useState(getProfile);
    const { username, role } = userProfile;
    const isInstructor = role === 'instructor';
    const isAdmin = role === 'admin';

    const [catalogCourses, setCatalogCourses] = useState([]);
    const [enrollments, setEnrollments] = useState([]);
    const [allUsers, setAllUsers] = useState([]);
    const [allEnrollments, setAllEnrollments] = useState([]);
    const [categories, setCategories] = useState([]);
    const [reports, setReports] = useState(emptyReports);
    const [enrollFilter, setEnrollFilter] = useState('');
    const [newCategoryName, setNewCategoryName] = useState('');
    const [editingCategoryId, setEditingCategoryId] = useState(null);
    const [editingCategoryName, setEditingCategoryName] = useState('');
    const [globalStats, setGlobalStats] = useState(emptyStats);
    const [totalLearnersCount, setTotalLearnersCount] = useState(0);
    const [activeTab, setActiveTab] = useState('dashboard');
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [newCourse, setNewCourse] = useState(emptyCourse);
    const [profileForm, setProfileForm] = useState({ username: username, email: localStorage.getItem('email') || '' });
    const [message, setMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const toList = (data) => (Array.isArray(data) ? data : (data?.results || []));

    const fetchCatalog = async () => {
        try {
            const res = await API.get('/courses/');
            setCatalogCourses(toList(res.data));
        } catch (err) {
            console.error('Catalog fetch failed.', err);
        }
    };

    const fetchMyEnrollments = async () => {
        try {
            const res = await API.get('/courses/my-enrollments/');
            setEnrollments(toList(res.data));
        } catch (err) {
            console.error('Enrollment fetch failed.', err);
        }
    };

    const fetchDashboardMetrics = async () => {
        try {
            const res = await API.get('/courses/dashboard-summary/');
            setGlobalStats({ ...emptyStats, ...(res.data.global || {}) });
            setTotalLearnersCount(res.data.instructor_specific?.total_learners || 0);
        } catch (err) {
            console.error('Dashboard summary fetch failed.', err);
        }
    };

    const fetchProfile = async () => {
        try {
            const res = await API.get('/courses/profile/');
            setProfileForm({ username: res.data.username || username, email: res.data.email || '' });
        } catch (err) {
            console.error('Profile fetch failed.', err);
        }
    };

    const fetchUsers = async () => {
        try {
            const res = await API.get('/courses/admin/users/');
            setAllUsers(toList(res.data));
        } catch (err) {
            console.error('Users fetch failed.', err);
        }
    };

    const fetchAllEnrollments = async () => {
        try {
            const res = await API.get('/courses/admin/enrollments/');
            setAllEnrollments(toList(res.data));
        } catch (err) {
            console.error('All enrollments fetch failed.', err);
        }
    };

    const fetchCategories = async () => {
        try {
            const res = await API.get('/courses/admin/categories/');
            setCategories(toList(res.data));
        } catch (err) {
            console.error('Categories fetch failed.', err);
        }
    };

    const fetchReports = async () => {
        try {
            const res = await API.get('/courses/admin/reports/');
            setReports({ ...emptyReports, ...res.data });
        } catch (err) {
            console.error('Reports fetch failed.', err);
        }
    };

    useEffect(() => {
        fetchCatalog();
        fetchDashboardMetrics();
        fetchProfile();
        if (isAdmin) { fetchUsers(); fetchAllEnrollments(); fetchCategories(); fetchReports(); }
        if (!isInstructor && !isAdmin) fetchMyEnrollments();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const flash = (text, isError = false) => {
        if (isError) { setErrorMessage(text); setMessage(''); }
        else { setMessage(text); setErrorMessage(''); }
        if (mainRef.current) mainRef.current.scrollTo({ top: 0, behavior: 'smooth' });
        setTimeout(() => { setMessage(''); setErrorMessage(''); }, 4000);
    };

    const errorText = (err, fallback) => {
        const data = err.response?.data;
        const pick = data?.error || data?.detail;
        if (pick) return Array.isArray(pick) ? pick.join(' ') : pick;
        if (data && typeof data === 'object') return Object.values(data).flat().join(' ');
        return fallback;
    };

    const handleLogout = () => {
        localStorage.clear();
        navigate('/signin');
    };

    const handleUpdateProfile = async (e) => {
        e.preventDefault();
        try {
            const res = await API.put('/courses/profile/', profileForm);
            flash(res.data.message || 'Profile updated successfully!');
            setUserProfile(prev => ({ ...prev, username: profileForm.username }));
            localStorage.setItem('username', profileForm.username);
            localStorage.setItem('email', profileForm.email);
            fetchCatalog();
        } catch (err) {
            flash(errorText(err, 'Profile update failed.'), true);
        }
    };

    const handleEnroll = async (courseId) => {
        try {
            await API.post('/courses/enroll/', { course: courseId });
            flash('Success! You are now enrolled in this course.');
            fetchMyEnrollments();
            fetchDashboardMetrics();
        } catch (err) {
            flash(errorText(err, 'Could not complete enrollment.'), true);
        }
    };

    const handleCreateCourse = async (e) => {
        e.preventDefault();
        try {
            await API.post('/courses/', {
                title: newCourse.title,
                category_input: newCourse.categoryName,
                description: newCourse.description,
                duration: newCourse.duration,
                lessons: newCourse.lessons,
            });
            flash(`Success! Course "${newCourse.title}" was added to the database.`);
            setShowCreateModal(false);
            setNewCourse(emptyCourse);
            fetchCatalog();
            fetchDashboardMetrics();
        } catch (err) {
            setShowCreateModal(false);
            flash(errorText(err, 'Failed to create course.'), true);
        }
    };

    // ---------- Admin actions ----------
    const handleChangeRole = async (user, newRole) => {
        if (newRole === user.role) return;
        if (!window.confirm(`Change ${user.username} from ${user.role} to ${newRole}?`)) return;
        try {
            const res = await API.patch(`/courses/admin/users/${user.id}/`, { role: newRole });
            flash(res.data.message || 'Role updated.');
            fetchUsers();
            fetchDashboardMetrics();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not change role.'), true);
        }
    };

    const handleDeleteUser = async (user) => {
        if (!window.confirm(`Delete user "${user.username}"? This cannot be undone.`)) return;
        try {
            const res = await API.delete(`/courses/admin/users/${user.id}/`);
            flash(res.data.message || 'User deleted.');
            fetchUsers();
            fetchAllEnrollments();
            fetchCatalog();
            fetchCategories();
            fetchDashboardMetrics();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not delete user.'), true);
        }
    };

    const handleDeleteCourse = async (course) => {
        if (!window.confirm(`Delete course "${course.title}"? Enrollments in it will be removed too.`)) return;
        try {
            const res = await API.delete(`/courses/admin/courses/${course.id}/`);
            flash(res.data.message || 'Course deleted.');
            fetchCatalog();
            fetchAllEnrollments();
            fetchCategories();
            fetchDashboardMetrics();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not delete course.'), true);
        }
    };

    const handleRemoveEnrollment = async (row) => {
        if (!window.confirm(`Remove ${row.student_name} from "${row.course_title}"?`)) return;
        try {
            const res = await API.delete(`/courses/admin/enrollments/${row.id}/`);
            flash(res.data.message || 'Enrollment removed.');
            fetchAllEnrollments();
            fetchDashboardMetrics();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not remove enrollment.'), true);
        }
    };

    const handleAddCategory = async (e) => {
        e.preventDefault();
        try {
            const res = await API.post('/courses/admin/categories/', { name: newCategoryName });
            flash(res.data.message || 'Category added.');
            setNewCategoryName('');
            fetchCategories();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not add category.'), true);
        }
    };

    const handleSaveCategory = async (cat) => {
        try {
            const res = await API.patch(`/courses/admin/categories/${cat.id}/`, { name: editingCategoryName });
            flash(res.data.message || 'Category renamed.');
            setEditingCategoryId(null);
            setEditingCategoryName('');
            fetchCategories();
            fetchCatalog();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not rename category.'), true);
        }
    };

    const handleDeleteCategory = async (cat) => {
        if (!window.confirm(`Delete category "${cat.name}"?`)) return;
        try {
            const res = await API.delete(`/courses/admin/categories/${cat.id}/`);
            flash(res.data.message || 'Category deleted.');
            fetchCategories();
            fetchReports();
        } catch (err) {
            flash(errorText(err, 'Could not delete category.'), true);
        }
    };

    const enrolledCourses = enrollments.map(e => {
        const full = catalogCourses.find(c => c.id === e.course);
        return full || { id: e.course, title: e.course_title, category_name: 'General', instructor_name: '', duration: '', lessons: '' };
    });
    const enrolledIds = enrollments.map(e => e.course);
    const taughtCourses = catalogCourses.filter(c => c.instructor_name === username);

    const goTab = (tab) => { setActiveTab(tab); setSelectedCourse(null); };

    const navStyle = (tab) => {
        const active = activeTab === tab && !selectedCourse;
        return {
            ...navItemStyle,
            backgroundColor: active ? '#eff6ff' : 'transparent',
            color: active ? '#2563eb' : '#475569',
            fontWeight: active ? '600' : '400'
        };
    };

    const renderCourseCard = (course, buttonLabel, onClick, buttonColor, disabled = false, extraButton = null) => (
        <div key={course.id} style={courseCardStyle}>
            <div style={cardHeaderStyle}><span style={categoryBadgeStyle}>{course.category_name || 'General'}</span></div>
            <div style={cardBodyStyle}>
                <h4 style={courseTitleStyle}>{course.title}</h4>
                {course.instructor_name && <p style={instructorTextStyle}>By {course.instructor_name}</p>}
                <div style={metaDataRowStyle}>
                    {course.duration && <span>⏱️ {course.duration}</span>}
                    {course.lessons && <span>📖 {course.lessons}</span>}
                </div>
            </div>
            {buttonLabel && (
                <div style={{ ...cardFooterStyle, display: 'flex', gap: '10px' }}>
                    <button
                        onClick={onClick}
                        disabled={disabled}
                        style={{
                            ...enrollButtonStyle,
                            ...(buttonColor ? { backgroundColor: buttonColor } : {}),
                            ...(disabled ? { opacity: 0.6, cursor: 'not-allowed' } : {})
                        }}
                    >
                        {buttonLabel}
                    </button>
                    {extraButton}
                </div>
            )}
        </div>
    );

    const renderStat = (icon, bg, label, value) => (
        <div style={statCardStyle} key={label}>
            <div style={{ ...iconBadgeStyle, backgroundColor: bg }}>{icon}</div>
            <div>
                <h4 style={statLabelStyle}>{label}</h4>
                <p style={statValueStyle}>{value}</p>
            </div>
        </div>
    );

    const renderPlatformOverview = () => (
        <>
            <h3 style={sectionTitleStyle}>Platform Overview</h3>
            <section style={metricsGridStyle}>
                {renderStat('🌐', '#eff6ff', 'Total Users', globalStats.total_users)}
                {renderStat('📘', '#ecfdf5', 'Total Courses', globalStats.total_courses)}
                {renderStat('📝', '#fff7ed', 'Total Enrollments', globalStats.total_enrollments)}
                {renderStat('🎓', '#f5f3ff', 'Students', globalStats.role_counts?.students ?? 0)}
                {renderStat('🧑‍🏫', '#fef2f2', 'Instructors', globalStats.role_counts?.instructors ?? 0)}
            </section>
        </>
    );

    const renderEmpty = (title, text, buttonText, onClick) => (
        <div style={emptyBoxStyle}>
            <span style={{ fontSize: '40px' }}>📁</span>
            <h4 style={{ margin: '15px 0 5px 0', color: '#334155' }}>{title}</h4>
            <p style={{ color: '#64748b', fontSize: '14px', margin: '0 0 20px 0' }}>{text}</p>
            {buttonText && (
                <button onClick={onClick} style={{ ...enrollButtonStyle, width: 'auto', padding: '10px 20px' }}>{buttonText}</button>
            )}
        </div>
    );

    const renderClassroom = () => (
        <div>
            <button onClick={() => setSelectedCourse(null)} style={backButtonStyle}>← Back to List</button>
            <header style={headerPanelStyle}>
                <span style={categoryBadgeStyle}>{selectedCourse.category_name || 'General'}</span>
                <h2 style={{ margin: '12px 0 6px 0', fontSize: '26px', color: '#0f172a' }}>{selectedCourse.title}</h2>
                {selectedCourse.instructor_name && (
                    <p style={{ margin: 0, color: '#64748b' }}>Instructor: {selectedCourse.instructor_name}</p>
                )}
            </header>
            <div style={{ display: 'flex', gap: '30px', flexWrap: 'wrap' }}>
                <div style={videoBoxStyle}>📺 [Course Lecture Video Player Placeholder]</div>
                <div style={syllabusBoxStyle}>
                    <h3 style={{ margin: '0 0 15px 0', fontSize: '16px' }}>About this course</h3>
                    <p style={{ color: '#475569', lineHeight: '1.7', margin: 0 }}>
                        {selectedCourse.description || 'No description has been added for this course yet.'}
                    </p>
                </div>
            </div>
        </div>
    );

    const renderProfile = () => (
        <>
            <header style={headerPanelStyle}>
                <h2 style={headingStyle}>Profile Management</h2>
                <p style={subTextStyle}>Update your account details. Your role is <b style={{ textTransform: 'capitalize' }}>{role}</b>.</p>
            </header>
            <form onSubmit={handleUpdateProfile} style={formBoxStyle}>
                <label style={labelStyle}>Username</label>
                <input
                    style={inputStyle}
                    value={profileForm.username}
                    onChange={(e) => setProfileForm({ ...profileForm, username: e.target.value })}
                    required
                />
                <label style={labelStyle}>Email Address</label>
                <input
                    type="email"
                    style={inputStyle}
                    value={profileForm.email}
                    onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                />
                <button type="submit" style={enrollButtonStyle}>Save Changes</button>
            </form>
        </>
    );

    const renderUsers = () => (
        <>
            <header style={headerPanelStyle}>
                <h2 style={headingStyle}>Manage Users</h2>
                <p style={subTextStyle}>Change roles or remove accounts. A role change takes effect the next time that user signs in.</p>
            </header>
            {allUsers.length === 0 ? (
                renderEmpty('No users loaded', 'If this stays empty, check the Django terminal for errors.')
            ) : (
                <div style={tableWrapStyle}>
                    <table style={tableStyle}>
                        <thead>
                            <tr>
                                <th style={thStyle}>ID</th>
                                <th style={thStyle}>Username</th>
                                <th style={thStyle}>Email</th>
                                <th style={thStyle}>Role</th>
                                <th style={thStyle}>Joined</th>
                                <th style={thStyle}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {allUsers.map(u => {
                                const isSelf = u.username === username;
                                return (
                                    <tr key={u.id}>
                                        <td style={tdStyle}>{u.id}</td>
                                        <td style={{ ...tdStyle, fontWeight: '600' }}>
                                            {u.username}{isSelf && <span style={youTagStyle}>You</span>}
                                        </td>
                                        <td style={tdStyle}>{u.email || '—'}</td>
                                        <td style={tdStyle}>
                                            <select
                                                value={u.role}
                                                disabled={isSelf}
                                                onChange={(e) => handleChangeRole(u, e.target.value)}
                                                style={{ ...selectStyle, ...(isSelf ? { opacity: 0.6, cursor: 'not-allowed' } : {}) }}
                                            >
                                                <option value="student">Student</option>
                                                <option value="instructor">Instructor</option>
                                                <option value="admin">Admin</option>
                                            </select>
                                        </td>
                                        <td style={tdStyle}>{u.date_joined ? new Date(u.date_joined).toLocaleDateString() : '—'}</td>
                                        <td style={tdStyle}>
                                            <button
                                                onClick={() => handleDeleteUser(u)}
                                                disabled={isSelf}
                                                style={{ ...deleteButtonStyle, ...(isSelf ? { opacity: 0.4, cursor: 'not-allowed' } : {}) }}
                                            >
                                                🗑 Delete
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </>
    );

    const renderEnrollments = () => {
        const q = enrollFilter.trim().toLowerCase();
        const rows = allEnrollments.filter(r =>
            !q || r.student_name.toLowerCase().includes(q) || r.course_title.toLowerCase().includes(q)
        );
        return (
            <>
                <header style={headerPanelStyle}>
                    <h2 style={headingStyle}>Manage Enrollments</h2>
                    <p style={subTextStyle}>See which student is in which course. Removing an enrollment does not delete the student or the course.</p>
                </header>

                <input
                    style={{ ...inputStyle, maxWidth: '360px', marginBottom: '20px' }}
                    placeholder="🔍 Search by student or course..."
                    value={enrollFilter}
                    onChange={(e) => setEnrollFilter(e.target.value)}
                />

                {allEnrollments.length === 0 ? (
                    renderEmpty('No enrollments yet', 'When students enroll in courses, they will appear here.')
                ) : rows.length === 0 ? (
                    renderEmpty('No matches', 'Try a different search word.')
                ) : (
                    <div style={tableWrapStyle}>
                        <table style={tableStyle}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>ID</th>
                                    <th style={thStyle}>Student</th>
                                    <th style={thStyle}>Course</th>
                                    <th style={thStyle}>Enrolled On</th>
                                    <th style={thStyle}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rows.map(r => (
                                    <tr key={r.id}>
                                        <td style={tdStyle}>{r.id}</td>
                                        <td style={{ ...tdStyle, fontWeight: '600' }}>{r.student_name}</td>
                                        <td style={tdStyle}>{r.course_title}</td>
                                        <td style={tdStyle}>{r.enrolled_at ? new Date(r.enrolled_at).toLocaleDateString() : '—'}</td>
                                        <td style={tdStyle}>
                                            <button onClick={() => handleRemoveEnrollment(r)} style={deleteButtonStyle}>✖ Remove</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </>
        );
    };

    // ---------- Step 2: Categories ----------
    const renderCategories = () => (
        <>
            <header style={headerPanelStyle}>
                <h2 style={headingStyle}>Manage Categories</h2>
                <p style={subTextStyle}>Add, rename or delete course categories. A category that still has courses cannot be deleted.</p>
            </header>

            <form onSubmit={handleAddCategory} style={{ display: 'flex', gap: '12px', marginBottom: '24px', flexWrap: 'wrap' }}>
                <input
                    style={{ ...inputStyle, maxWidth: '360px', marginBottom: 0 }}
                    placeholder="New category name, e.g. Data Science"
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    required
                />
                <button type="submit" style={{ ...enrollButtonStyle, width: 'auto', padding: '12px 22px' }}>➕ Add Category</button>
            </form>

            {categories.length === 0 ? (
                renderEmpty('No categories yet', 'Add one above, or create a course (it creates its category automatically).')
            ) : (
                <div style={tableWrapStyle}>
                    <table style={tableStyle}>
                        <thead>
                            <tr>
                                <th style={thStyle}>ID</th>
                                <th style={thStyle}>Name</th>
                                <th style={thStyle}>Courses</th>
                                <th style={thStyle}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {categories.map(c => {
                                const editing = editingCategoryId === c.id;
                                return (
                                    <tr key={c.id}>
                                        <td style={tdStyle}>{c.id}</td>
                                        <td style={{ ...tdStyle, fontWeight: '600' }}>
                                            {editing ? (
                                                <input
                                                    style={{ ...inputStyle, marginBottom: 0, padding: '8px 12px', maxWidth: '260px' }}
                                                    value={editingCategoryName}
                                                    onChange={(e) => setEditingCategoryName(e.target.value)}
                                                    autoFocus
                                                />
                                            ) : c.name}
                                        </td>
                                        <td style={tdStyle}>{c.course_count}</td>
                                        <td style={{ ...tdStyle, display: 'flex', gap: '8px' }}>
                                            {editing ? (
                                                <>
                                                    <button onClick={() => handleSaveCategory(c)} style={{ ...deleteButtonStyle, backgroundColor: '#d1fae5', color: '#065f46' }}>✔ Save</button>
                                                    <button onClick={() => { setEditingCategoryId(null); setEditingCategoryName(''); }} style={{ ...deleteButtonStyle, backgroundColor: '#e2e8f0', color: '#334155' }}>Cancel</button>
                                                </>
                                            ) : (
                                                <>
                                                    <button onClick={() => { setEditingCategoryId(c.id); setEditingCategoryName(c.name); }} style={{ ...deleteButtonStyle, backgroundColor: '#eff6ff', color: '#2563eb' }}>✏ Rename</button>
                                                    <button onClick={() => handleDeleteCategory(c)} style={deleteButtonStyle}>🗑 Delete</button>
                                                </>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </>
    );

    // ---------- Step 3: Reports ----------
    const renderBarChart = (title, items, color, emptyText) => {
        const max = Math.max(1, ...items.map(i => i.value));
        return (
            <div style={chartBoxStyle}>
                <h3 style={{ margin: '0 0 18px 0', fontSize: '16px', color: '#1e293b' }}>{title}</h3>
                {items.length === 0 ? (
                    <p style={{ color: '#64748b', fontSize: '14px', margin: 0 }}>{emptyText}</p>
                ) : (
                    items.map((item, idx) => (
                        <div key={`${item.label}-${idx}`} style={barRowStyle}>
                            <div style={barLabelStyle} title={item.label}>{item.label}</div>
                            <div style={barTrackStyle}>
                                <div style={{ ...barFillStyle, width: `${(item.value / max) * 100}%`, backgroundColor: color }} />
                            </div>
                            <div style={barValueStyle}>{item.value}</div>
                        </div>
                    ))
                )}
            </div>
        );
    };

    const renderReports = () => (
        <>
            <header style={headerPanelStyle}>
                <h2 style={headingStyle}>Reports</h2>
                <p style={subTextStyle}>Live numbers from the database. Charts update when you open this page.</p>
            </header>

            <section style={metricsGridStyle}>
                {renderStat('🌐', '#eff6ff', 'Total Users', globalStats.total_users)}
                {renderStat('📘', '#ecfdf5', 'Total Courses', globalStats.total_courses)}
                {renderStat('📝', '#fff7ed', 'Total Enrollments', globalStats.total_enrollments)}
            </section>

            <div style={chartGridStyle}>
                {renderBarChart('Enrollments per course', reports.enrollments_per_course, '#4f46e5', 'No courses yet.')}
                {renderBarChart('New users per week (last 8 weeks)', reports.new_users_per_week, '#10b981', 'No data yet.')}
                {renderBarChart('Courses per category', reports.courses_per_category, '#f59e0b', 'No categories yet.')}
                {renderBarChart('Users by role', reports.users_by_role, '#ef4444', 'Role data is not available.')}
            </div>
        </>
    );

    const renderStudent = () => (
        <>
            {activeTab === 'dashboard' && (
                <>
                    <header style={headerPanelStyle}>
                        <h2 style={headingStyle}>Welcome Back, Student {username}!</h2>
                        <p style={subTextStyle}>Here is an overview of your active academic progress.</p>
                    </header>
                    <section style={metricsGridStyle}>
                        {renderStat('📚', '#eff6ff', 'Enrolled Courses', enrolledCourses.length)}
                        {renderStat('📈', '#ecfdf5', 'Overall Progress', enrolledCourses.length > 0 ? '12%' : '0%')}
                        {renderStat('⏱️', '#fff7ed', 'Study Hours Logged', enrolledCourses.length > 0 ? '4.5 hrs' : '0 hrs')}
                    </section>
                    {renderPlatformOverview()}
                    <h3 style={sectionTitleStyle}>Available Course Catalog</h3>
                    {catalogCourses.length === 0 ? (
                        renderEmpty('No courses available yet', 'Courses created by instructors will appear here.')
                    ) : (
                        <section style={courseGridStyle}>
                            {catalogCourses.map(course => {
                                const already = enrolledIds.includes(course.id);
                                return renderCourseCard(
                                    course,
                                    already ? '✔ Enrolled' : 'Enroll Now',
                                    () => handleEnroll(course.id),
                                    already ? '#10b981' : undefined,
                                    already
                                );
                            })}
                        </section>
                    )}
                </>
            )}

            {activeTab === 'my-courses' && (
                <>
                    <header style={headerPanelStyle}>
                        <h2 style={headingStyle}>My Enrolled Courses</h2>
                        <p style={subTextStyle}>Open a classroom to watch lectures for your active courses.</p>
                    </header>
                    {enrolledCourses.length === 0 ? (
                        renderEmpty('No Enrolled Courses Found', "You haven't registered into any courses yet.", 'Browse Main Catalog', () => goTab('dashboard'))
                    ) : (
                        <section style={courseGridStyle}>
                            {enrolledCourses.map(course =>
                                renderCourseCard(course, '▶ Continue Learning', () => setSelectedCourse(course), '#10b981')
                            )}
                        </section>
                    )}
                </>
            )}
        </>
    );

    const renderInstructor = () => (
        <>
            {activeTab === 'dashboard' && (
                <>
                    <header style={headerPanelStyle}>
                        <h2 style={headingStyle}>Welcome Back, Instructor {username}!</h2>
                        <p style={subTextStyle}>Manage your teaching environment, view lecture updates, and check course metrics.</p>
                    </header>
                    <section style={metricsGridStyle}>
                        {renderStat('📘', '#eff6ff', 'Courses Taught', taughtCourses.length)}
                        {renderStat('👥', '#ecfdf5', 'Total Learners', totalLearnersCount)}
                        {renderStat('📚', '#fff7ed', 'Catalog Size', catalogCourses.length)}
                    </section>
                    {renderPlatformOverview()}
                    <h3 style={sectionTitleStyle}>Your Courses</h3>
                    {taughtCourses.length === 0 ? (
                        renderEmpty('No courses yet', 'Create your first course so students can enroll.', '+ Create Course', () => setShowCreateModal(true))
                    ) : (
                        <section style={courseGridStyle}>
                            {taughtCourses.map(course => renderCourseCard(course, '👁 View Details', () => setSelectedCourse(course), '#10b981'))}
                        </section>
                    )}
                </>
            )}

            {activeTab === 'my-courses' && (
                <>
                    <header style={headerPanelStyle}>
                        <h2 style={headingStyle}>My Assigned Courses</h2>
                        <p style={subTextStyle}>All courses you teach.</p>
                    </header>
                    {taughtCourses.length === 0 ? (
                        renderEmpty('No courses yet', 'Create your first course so students can enroll.', '+ Create Course', () => setShowCreateModal(true))
                    ) : (
                        <section style={courseGridStyle}>
                            {taughtCourses.map(course => renderCourseCard(course, '👁 View Details', () => setSelectedCourse(course), '#10b981'))}
                        </section>
                    )}
                </>
            )}
        </>
    );

    const renderAdmin = () => (
        <>
            <header style={headerPanelStyle}>
                <h2 style={headingStyle}>Welcome Back, Admin {username}!</h2>
                <p style={subTextStyle}>Monitor the whole platform: users, courses and enrollments.</p>
            </header>
            {renderPlatformOverview()}
            <h3 style={sectionTitleStyle}>All Courses</h3>
            {catalogCourses.length === 0 ? (
                renderEmpty('No courses yet', 'Courses created by instructors will appear here.')
            ) : (
                <section style={courseGridStyle}>
                    {catalogCourses.map(course => renderCourseCard(
                        course,
                        '👁 View Details',
                        () => setSelectedCourse(course),
                        '#4f46e5',
                        false,
                        <button onClick={() => handleDeleteCourse(course)} style={{ ...deleteButtonStyle, padding: '0 14px' }}>🗑</button>
                    ))}
                </section>
            )}
        </>
    );

    const renderBody = () => {
        if (selectedCourse) return renderClassroom();
        if (activeTab === 'profile') return renderProfile();
        if (isAdmin && activeTab === 'users') return renderUsers();
        if (isAdmin && activeTab === 'enrollments') return renderEnrollments();
        if (isAdmin && activeTab === 'categories') return renderCategories();
        if (isAdmin && activeTab === 'reports') return renderReports();
        if (isAdmin) return renderAdmin();
        return isInstructor ? renderInstructor() : renderStudent();
    };

    return (
        <div style={containerStyle}>
            <aside style={sidebarStyle}>
                <div style={logoAreaStyle}>
                    <span style={{ fontSize: '24px', marginRight: '10px' }}>🎓</span>
                    <span style={logoTextStyle}>EduPulse LMS</span>
                </div>

                <nav style={navGroupStyle}>
                    <div onClick={() => goTab('dashboard')} style={navStyle('dashboard')}>
                        <span style={{ marginRight: '12px' }}>📊</span> Dashboard
                    </div>
                    {!isAdmin && (
                        <div onClick={() => goTab('my-courses')} style={navStyle('my-courses')}>
                            <span style={{ marginRight: '12px' }}>📚</span> {isInstructor ? 'My Assigned Courses' : 'My Enrolled Courses'}
                        </div>
                    )}
                    {isAdmin && (
                        <div onClick={() => { goTab('users'); fetchUsers(); }} style={navStyle('users')}>
                            <span style={{ marginRight: '12px' }}>👥</span> Manage Users
                        </div>
                    )}
                    {isAdmin && (
                        <div onClick={() => { goTab('enrollments'); fetchAllEnrollments(); }} style={navStyle('enrollments')}>
                            <span style={{ marginRight: '12px' }}>📝</span> Manage Enrollments
                        </div>
                    )}
                    {isAdmin && (
                        <div onClick={() => { goTab('categories'); fetchCategories(); }} style={navStyle('categories')}>
                            <span style={{ marginRight: '12px' }}>🏷️</span> Manage Categories
                        </div>
                    )}
                    {isAdmin && (
                        <div onClick={() => { goTab('reports'); fetchReports(); fetchDashboardMetrics(); }} style={navStyle('reports')}>
                            <span style={{ marginRight: '12px' }}>📈</span> Reports
                        </div>
                    )}
                    <div onClick={() => goTab('profile')} style={navStyle('profile')}>
                        <span style={{ marginRight: '12px' }}>👤</span> Profile Management
                    </div>
                    {isInstructor && (
                        <div
                            onClick={() => setShowCreateModal(true)}
                            style={{ ...navItemStyle, color: '#4f46e5', fontWeight: '600', backgroundColor: '#f5f3ff', marginTop: '20px' }}
                        >
                            <span style={{ marginRight: '12px' }}>➕</span> Create Course
                        </div>
                    )}
                </nav>

                <div style={profileBadgeStyle}>
                    <div style={{ fontSize: '20px', marginRight: '10px' }}>{isAdmin ? '🛡️' : (isInstructor ? '🧑‍🏫' : '👤')}</div>
                    <div>
                        <div style={{ fontWeight: '600', color: '#1e293b', fontSize: '14px' }}>{username}</div>
                        <div style={{ fontSize: '12px', color: '#64748b', textTransform: 'capitalize' }}>{role}</div>
                    </div>
                </div>
                <button onClick={handleLogout} style={logoutButtonStyle}>🚪 Sign Out</button>
            </aside>

            <main ref={mainRef} style={mainContentStyle}>
                <div style={contentWrapStyle}>
                    {message && <div style={successBannerStyle}>✨ {message}</div>}
                    {errorMessage && <div style={errorBannerStyle}>❌ {errorMessage}</div>}
                    {renderBody()}
                </div>
            </main>

            {showCreateModal && (
                <div style={overlayStyle} onClick={() => setShowCreateModal(false)}>
                    <form onSubmit={handleCreateCourse} style={modalStyle} onClick={(e) => e.stopPropagation()}>
                        <h3 style={{ margin: '0 0 20px 0', fontSize: '20px', color: '#0f172a' }}>Create a New Course</h3>

                        <label style={labelStyle}>Course Title *</label>
                        <input style={inputStyle} value={newCourse.title} onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })} placeholder="e.g. Introduction to Machine Learning" required />

                        <label style={labelStyle}>Category</label>
                        <input style={inputStyle} value={newCourse.categoryName} onChange={(e) => setNewCourse({ ...newCourse, categoryName: e.target.value })} placeholder="e.g. Development" />

                        <label style={labelStyle}>Description</label>
                        <textarea style={{ ...inputStyle, height: '80px', resize: 'vertical' }} value={newCourse.description} onChange={(e) => setNewCourse({ ...newCourse, description: e.target.value })} placeholder="What will students learn?" />

                        <div style={{ display: 'flex', gap: '16px' }}>
                            <div style={{ flex: 1 }}>
                                <label style={labelStyle}>Duration</label>
                                <input style={inputStyle} value={newCourse.duration} onChange={(e) => setNewCourse({ ...newCourse, duration: e.target.value })} />
                            </div>
                            <div style={{ flex: 1 }}>
                                <label style={labelStyle}>Lessons</label>
                                <input style={inputStyle} value={newCourse.lessons} onChange={(e) => setNewCourse({ ...newCourse, lessons: e.target.value })} />
                            </div>
                        </div>

                        <div style={{ display: 'flex', gap: '12px', marginTop: '4px' }}>
                            <button type="button" onClick={() => setShowCreateModal(false)} style={{ ...enrollButtonStyle, backgroundColor: '#e2e8f0', color: '#334155' }}>Cancel</button>
                            <button type="submit" style={enrollButtonStyle}>Publish Course</button>
                        </div>
                    </form>
                </div>
            )}
        </div>
    );
};

// ---------- Styles ----------
const containerStyle = { position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', backgroundColor: '#f1f5f9', fontFamily: '"Inter", "Segoe UI", sans-serif', textAlign: 'left' };

const sidebarStyle = { width: '250px', flexShrink: 0, backgroundColor: '#ffffff', borderRight: '1px solid #e2e8f0', padding: '28px 18px', display: 'flex', flexDirection: 'column', height: '100%', boxSizing: 'border-box', overflowY: 'auto' };
const logoAreaStyle = { display: 'flex', alignItems: 'center', marginBottom: '36px', paddingLeft: '8px' };
const logoTextStyle = { fontSize: '19px', fontWeight: '800', color: '#1e293b', letterSpacing: '-0.5px' };

const navGroupStyle = { display: 'flex', flexDirection: 'column', gap: '6px', flexGrow: 1 };
const navItemStyle = { display: 'flex', alignItems: 'center', padding: '12px 14px', borderRadius: '8px', fontSize: '14px', color: '#475569', cursor: 'pointer', transition: 'all 0.2s ease' };

const profileBadgeStyle = { display: 'flex', alignItems: 'center', marginBottom: '12px', padding: '10px 12px', backgroundColor: '#f1f5f9', borderRadius: '8px' };
const logoutButtonStyle = { display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '12px', backgroundColor: '#fff1f2', color: '#e11d48', border: 'none', borderRadius: '8px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' };

const mainContentStyle = { flexGrow: 1, minWidth: 0, height: '100%', overflowY: 'auto', padding: '32px 40px', boxSizing: 'border-box' };
const contentWrapStyle = { maxWidth: '1150px', margin: '0 auto' };

const successBannerStyle = { backgroundColor: '#d1fae5', color: '#065f46', padding: '14px 18px', borderRadius: '10px', marginBottom: '24px', fontSize: '14px', fontWeight: '500' };
const errorBannerStyle = { backgroundColor: '#fee2e2', color: '#991b1b', padding: '14px 18px', borderRadius: '10px', marginBottom: '24px', fontSize: '14px', fontWeight: '500' };

const headerPanelStyle = { backgroundColor: '#ffffff', padding: '26px 30px', borderRadius: '14px', border: '1px solid #e2e8f0', marginBottom: '28px' };
const headingStyle = { margin: '0 0 6px 0', fontSize: '24px', fontWeight: '700', color: '#0f172a' };
const subTextStyle = { margin: 0, color: '#64748b', fontSize: '14px' };

const metricsGridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '36px' };
const statCardStyle = { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '14px', padding: '22px', display: 'flex', alignItems: 'center', gap: '16px' };
const iconBadgeStyle = { width: '48px', height: '48px', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', flexShrink: 0 };
const statLabelStyle = { margin: 0, fontSize: '13px', color: '#64748b', fontWeight: '500' };
const statValueStyle = { margin: '4px 0 0 0', fontSize: '26px', fontWeight: '700', color: '#0f172a' };

const sectionTitleStyle = { fontSize: '18px', color: '#1e293b', margin: '0 0 18px 0', fontWeight: '700' };

const courseGridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '24px' };
const courseCardStyle = { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '14px', overflow: 'hidden', display: 'flex', flexDirection: 'column' };
const cardHeaderStyle = { backgroundColor: '#f8fafc', padding: '14px 22px', borderBottom: '1px solid #f1f5f9' };
const categoryBadgeStyle = { backgroundColor: '#eff6ff', color: '#2563eb', padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: '600' };
const cardBodyStyle = { padding: '22px', flexGrow: 1 };
const courseTitleStyle = { margin: '0 0 8px 0', fontSize: '17px', fontWeight: '700', color: '#0f172a', lineHeight: '1.4' };
const instructorTextStyle = { margin: '0 0 16px 0', fontSize: '14px', color: '#64748b' };
const metaDataRowStyle = { display: 'flex', gap: '16px', fontSize: '13px', color: '#475569' };
const cardFooterStyle = { padding: '16px 22px', borderTop: '1px solid #f1f5f9' };
const enrollButtonStyle = { width: '100%', padding: '12px', backgroundColor: '#4f46e5', color: '#ffffff', border: 'none', borderRadius: '8px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' };

const backButtonStyle = { padding: '8px 16px', backgroundColor: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '8px', cursor: 'pointer', marginBottom: '20px', fontWeight: '600' };
const videoBoxStyle = { flex: 2, minWidth: '300px', backgroundColor: '#0f172a', borderRadius: '14px', height: '320px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '18px' };
const syllabusBoxStyle = { flex: 1, minWidth: '250px', backgroundColor: '#ffffff', padding: '22px', borderRadius: '14px', border: '1px solid #e2e8f0' };
const emptyBoxStyle = { textAlign: 'center', padding: '60px 20px', border: '2px dashed #cbd5e1', borderRadius: '14px', backgroundColor: '#ffffff' };

const formBoxStyle = { backgroundColor: '#ffffff', padding: '28px', borderRadius: '14px', border: '1px solid #e2e8f0', maxWidth: '560px' };
const overlayStyle = { position: 'fixed', inset: 0, backgroundColor: 'rgba(15,23,42,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2000, padding: '20px' };
const modalStyle = { backgroundColor: '#ffffff', borderRadius: '16px', padding: '28px', width: '100%', maxWidth: '520px', maxHeight: '90vh', overflowY: 'auto', boxSizing: 'border-box' };
const labelStyle = { display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', margin: '0 0 8px 0' };
const inputStyle = { width: '100%', padding: '12px 16px', boxSizing: 'border-box', border: '1px solid #e0e0e0', borderRadius: '8px', fontSize: '15px', backgroundColor: '#f9fafb', color: '#333', outline: 'none', marginBottom: '18px', fontFamily: 'inherit' };

const tableWrapStyle = { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '14px', overflowX: 'auto' };
const tableStyle = { width: '100%', borderCollapse: 'collapse', fontSize: '14px' };
const thStyle = { textAlign: 'left', padding: '14px 16px', backgroundColor: '#f8fafc', color: '#64748b', fontWeight: '600', fontSize: '12px', textTransform: 'uppercase', borderBottom: '1px solid #e2e8f0' };
const tdStyle = { padding: '14px 16px', color: '#334155', borderBottom: '1px solid #f1f5f9' };
const selectStyle = { padding: '6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', backgroundColor: '#f9fafb', fontSize: '13px', cursor: 'pointer' };
const deleteButtonStyle = { padding: '8px 12px', backgroundColor: '#fff1f2', color: '#e11d48', border: 'none', borderRadius: '8px', fontSize: '13px', fontWeight: '600', cursor: 'pointer' };
const youTagStyle = { marginLeft: '8px', backgroundColor: '#eef2ff', color: '#4f46e5', padding: '2px 8px', borderRadius: '10px', fontSize: '11px', fontWeight: '700' };

const chartGridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '24px' };
const chartBoxStyle = { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '14px', padding: '24px' };
const barRowStyle = { display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' };
const barLabelStyle = { width: '130px', flexShrink: 0, fontSize: '13px', color: '#475569', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' };
const barTrackStyle = { flexGrow: 1, height: '14px', backgroundColor: '#f1f5f9', borderRadius: '7px', overflow: 'hidden' };
const barFillStyle = { height: '100%', borderRadius: '7px', minWidth: '2px', transition: 'width 0.4s ease' };
const barValueStyle = { width: '32px', textAlign: 'right', fontSize: '13px', fontWeight: '700', color: '#0f172a' };

export default Dashboard;