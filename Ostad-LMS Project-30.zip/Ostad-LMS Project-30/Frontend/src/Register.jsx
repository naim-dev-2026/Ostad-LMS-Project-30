// src/Register.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import API from './api.jsx'; 

const Register = () => {
    const [formData, setFormData] = useState({ username: '', email: '', password: '', role: 'student' });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setError('');
        try {
            // FIXED: Removed absolute root slash to align flawlessly with the baseURL path configurations tracking parameters
            await API.post('auth/register/', formData);
            setMessage('Account created successfully! Redirecting to login...');
            setTimeout(() => {
                navigate('/signin');
            }, 2000);
        } catch (err) {
            if (err.response && err.response.data) {
                const errorData = err.response.data;
                const backendErrors = typeof errorData === 'object' 
                    ? Object.values(errorData).flat().join(' ') 
                    : 'Registration failed.';
                setError(backendErrors);
            } else {
                setError('Could not connect to the server. Please check if your Django terminal is running.');
            }
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: '40px', fontFamily: '"Segoe UI", Roboto, sans-serif' }}>
            <div style={{ 
                width: '100%', 
                maxWidth: '450px', 
                backgroundColor: '#ffffff', 
                padding: '40px', 
                borderRadius: '16px', 
                boxShadow: '0 10px 25px rgba(0, 0, 0, 0.05)',
                boxSizing: 'border-box'
            }}>
                <h2 style={{ textAlign: 'center', fontSize: '28px', fontWeight: '700', color: '#1a1a1a', marginBottom: '8px' }}>Create Account</h2>
                <p style={{ textAlign: 'center', color: '#666', fontSize: '14px', marginBottom: '32px' }}>Join the LMS platform to start learning or teaching</p>
                
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>Username</label>
                        <input type="text" placeholder="Enter a unique username" value={formData.username} style={inputStyle} onChange={(e) => setFormData({...formData, username: e.target.value})} required />
                    </div>
                    
                    <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>Email Address</label>
                        <input type="email" placeholder="name@example.com" value={formData.email} style={inputStyle} onChange={(e) => setFormData({...formData, email: e.target.value})} />
                    </div>
                    
                    <div style={{ marginBottom: '25px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>Password</label>
                        <input type="password" placeholder="••••••••" value={formData.password} style={inputStyle} onChange={(e) => setFormData({...formData, password: e.target.value})} required />
                    </div>
                    
                    <div style={{ marginBottom: '30px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>I want to register as a:</label>
                        <select style={inputStyle} value={formData.role} onChange={(e) => setFormData({...formData, role: e.target.value})}>
                            <option value="student">Student</option>
                            <option value="instructor">Instructor</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    
                    <button type="submit" style={{ 
                        width: '100%', 
                        padding: '14px', 
                        backgroundColor: '#4f46e5', 
                        color: '#ffffff', 
                        border: 'none', 
                        borderRadius: '8px', 
                        fontSize: '16px', 
                        fontWeight: '600', 
                        cursor: 'pointer'
                    }}>
                        Sign Up
                    </button>
                </form>
                
                {message && <div style={{ color: '#155724', backgroundColor: '#d4edda', padding: '12px', borderRadius: '6px', marginTop: '20px', textAlign: 'center', fontSize: '14px' }}>{message}</div>}
                {error && <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '12px', borderRadius: '6px', marginTop: '20px', textAlign: 'center', fontSize: '14px' }}>{error}</div>}

                <p style={{ marginTop: '28px', textAlign: 'center', fontSize: '14px', color: '#666' }}>
                    Already have an account? <Link to="/signin" style={{ color: '#4f46e5', fontWeight: '600', textDecoration: 'none' }}>Sign In</Link>
                </p>
            </div>
        </div>
    );
};

const inputStyle = {
    width: '100%',
    padding: '12px 16px',
    boxSizing: 'border-box',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    fontSize: '15px',
    backgroundColor: '#f9fafb',
    color: '#333',
    outline: 'none'
};

export default Register;
