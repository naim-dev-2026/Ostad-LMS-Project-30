// src/ForgotPassword.jsx
import { useState } from 'react';
import { Link } from 'react-router-dom';
import API from './api.jsx';

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setError('');
        try {
            // FIXED: Added an absolute tracking path with the mandatory trailing slash to guarantee Django route matching handles the handshake safely
            const res = await API.post('/auth/forgot-password/', { email });
            setMessage(res.data.message || 'Reset instructions have been printed to the server terminal console.');
        } catch (err) {
            if (err.response && err.response.data) {
                setError(err.response.data.error || 'Email entry failed verification.');
            } else {
                setError('Could not establish connection to the backend server terminal.');
            }
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: '40px', fontFamily: '"Segoe UI", Roboto, sans-serif' }}>
            <div style={{ 
                width: '100%', 
                maxWidth: '450px', 
                backgroundColor: '#ffffff', 
                padding: '40px', 
                borderRadius: '16px', 
                boxShadow: '0 10px 25px rgba(0, 0, 0, 0.05)',
                boxSizing: 'border-box'
            }}>
                <h2 style={{ textAlign: 'center', fontSize: '24px', fontWeight: '700', color: '#1a1a1a', marginBottom: '8px' }}>Account Recovery</h2>
                <p style={{ textAlign: 'center', color: '#666', fontSize: '13px', marginBottom: '28px', lineHeight: '1.5' }}>
                    Enter your email to print a secure token reset string to your terminal console.
                </p>
                
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '24px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#444', marginBottom: '8px' }}>Email Address</label>
                        <input 
                            type="email" 
                            placeholder="name@example.com" 
                            value={email} 
                            style={{
                                width: '100%',
                                padding: '12px 16px',
                                boxSizing: 'border-box',
                                border: '1px solid #e0e0e0',
                                borderRadius: '8px',
                                fontSize: '15px',
                                backgroundColor: '#f9fafb',
                                color: '#333',
                                outline: 'none'
                            }} 
                            onChange={(e) => setEmail(e.target.value)} 
                            required 
                        />
                    </div>
                    
                    <button type="submit" style={{ 
                        width: '100%', 
                        padding: '14px', 
                        backgroundColor: '#3b82f6', 
                        color: '#ffffff', 
                        border: 'none', 
                        borderRadius: '8px', 
                        fontSize: '15px', 
                        fontWeight: '600', 
                        cursor: 'pointer',
                        marginBottom: '20px'
                    }}>
                        Generate Reset Link
                    </button>
                </form>
                
                {message && <div style={{ color: '#155724', backgroundColor: '#d4edda', padding: '12px', borderRadius: '6px', marginBottom: '20px', textAlign: 'center', fontSize: '13px', lineHeight: '1.4' }}>{message}</div>}
                {error && <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '12px', borderRadius: '6px', marginBottom: '20px', textAlign: 'center', fontSize: '13px', lineHeight: '1.4' }}>{error}</div>}

                <p style={{ textAlign: 'center', fontSize: '14px', margin: '0' }}>
                    <Link to="/signin" style={{ color: '#3b82f6', fontWeight: '600', textDecoration: 'none' }}>Back to Sign In</Link>
                </p>
            </div>
        </div>
    );
};

export default ForgotPassword;
