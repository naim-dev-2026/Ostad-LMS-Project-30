// src/ResetPassword.jsx
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from './api';

const ResetPassword = () => {
    const { uid, token } = useParams(); // Automatically captures the token parameters from the URL path
    const navigate = useNavigate();
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(''); 
        setError('');
        try {
            // FIXED: Added an absolute leading forward slash to ensure precise API endpoint routing maps directly to DRF
            const res = await API.post('/auth/reset-password-confirm/', { uid, token, new_password: password });
            setMessage(res.data.message);
            
            // Auto-redirect to the sign-in page after a clean confirmation delay
            setTimeout(() => {
                navigate('/signin');
            }, 2500);
        } catch (err) {
            setError(err.response?.data?.error || 'The recovery link has expired or is invalid.');
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: '60px', fontFamily: 'sans-serif' }}>
            <div style={{ width: '100%', maxWidth: '420px', backgroundColor: '#ffffff', padding: '40px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.05)' }}>
                <h2 style={{ fontSize: '24px', fontWeight: '700', color: '#1a1a1a', marginBottom: '8px', textAlign: 'center' }}>Set New Password</h2>
                <p style={{ color: '#666', fontSize: '14px', marginBottom: '25px', textAlign: 'center' }}>Enter your fresh secure operational password values below.</p>
                
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', marginBottom: '8px', color: '#444' }}>New Secure Password</label>
                        <input type="password" style={inputStyle} placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required />
                    </div>
                    <button type="submit" style={btnStyle}>Update Password</button>
                </form>

                {message && <div style={{ color: '#155724', backgroundColor: '#d4edda', padding: '12px', borderRadius: '6px', marginTop: '20px', fontSize: '13px', textAlign: 'center' }}>{message}</div>}
                {error && <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '12px', borderRadius: '6px', marginTop: '20px', fontSize: '13px', textAlign: 'center' }}>{error}</div>}
            </div>
        </div>
    );
};

const inputStyle = { 
    width: '100%', 
    padding: '12px', 
    boxSizing: 'border-box', 
    border: '1px solid #e0e0e0', 
    borderRadius: '8px', 
    backgroundColor: '#f9fafb',
    outline: 'none',
    fontSize: '15px'
};

const btnStyle = { 
    width: '100%', 
    padding: '14px', 
    backgroundColor: '#10b981', 
    color: '#fff', 
    border: 'none', 
    borderRadius: '8px', 
    fontSize: '16px', 
    fontWeight: '600', 
    cursor: 'pointer' 
};

export default ResetPassword;
