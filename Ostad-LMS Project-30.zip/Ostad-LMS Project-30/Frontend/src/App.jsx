// src/App.jsx
import { Routes, Route, Navigate } from 'react-router-dom';
import Register from './Register';
import Login from './Login';
import Dashboard from './Dashboard';

// NEW: Imported the password recovery view sheets
import ForgotPassword from './ForgotPassword';
import ResetPassword from './ResetPassword';

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', backgroundColor: '#f8fafc', minHeight: '100vh' }}>
      <Routes>
        {/* Base Navigation Redirect */}
        <Route path="/" element={<Navigate to="/signup" />} />
        
        {/* Active Application Routes */}
        <Route path="/signup" element={<Register />} />
        <Route path="/signin" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        
        {/* ASSIGNMENT SPECIFICATION: Password Management UI Routing links */}
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:uid/:token" element={<ResetPassword />} />
      </Routes>
    </div>
  );
}

export default App;




